Digital Desolation is a typeface designed by JapanYoshi on FontStruct.

Anyone is free to use this font personally. I would appreciate a thank-you message and a link to the finished project if you used this font anywhere.

For commercial purposes, please contact me in some way. I would probably give the thumbs-up, but I need to know where and how it is used.

japanyoshi.deviantart.com
behance.net/japanyoshi
japanyoshi777@gmail.com